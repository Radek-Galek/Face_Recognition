
import cv2
import matplotlib.pyplot as plt
import os



face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades +'haarcascade_frontalface_default.xml')

count = 0

webcam = cv2.VideoCapture(0)

while True:
    successful_frame_read, frame = webcam.read()
    grayscaled_img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY,1)
    face_coordinates = face_cascade.detectMultiScale(grayscaled_img, 1.3, 5)

    for (x, y, w, h) in face_coordinates:
        roi_color = frame[y:y + h, x:x + w]

    for (x , y , w , h) in face_coordinates:
        face = frame[y:y+h, x:x+w] #slice the face from the image
        if count < 4:
            cv2.imwrite(str(count)+'.jpg', face) #save the image
            count += 1
        cv2.rectangle(frame , (x , y) , (x+w , y+h) , (255 ,0  , 0) , 5)


    cv2.imshow("show", frame)
    key = cv2.waitKey(1)

    if key==81 or key ==113:
        break

print("code completed")
