

import cv2
import face_recognition
import os
import numpy as np

path = '/Users/radekgalek/Documents/code/Face_id/Images'

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades +'haarcascade_frontalface_default.xml')

images = []
names = []
encodeList = []

for img in os.listdir(path):
    if not img.startswith('.'):
        pic = face_recognition.load_image_file(os.path.join(path,img))
        pic = cv2.cvtColor(pic,cv2.COLOR_BGR2RGB)
        images.append(pic)
        names.append(img.rsplit( ".", 1 )[ 0 ] )

webcam = cv2.VideoCapture(0)

imgRG = face_recognition.load_image_file('/Users/radekgalek/Documents/code/Face_id/Images/Radek_Galek.jpg')
imgRG = cv2.cvtColor(imgRG, cv2.COLOR_BGR2RGB)
encodeR = face_recognition.face_encodings(imgRG)[0]
    
for img in images:
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    encode = face_recognition.face_encodings(img)[0]
    encodeList.append(encode)


font = cv2.FONT_HERSHEY_COMPLEX


while True:
    successful_frame_read, frame = webcam.read()
    grayscaled_img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY,1)
    face_coordinates = face_cascade.detectMultiScale(grayscaled_img, 1.3, 5)


    for (x , y , w , h) in face_coordinates:
        newW = ((np.array(w).item())/2)
        positive = None
        face = frame[y:y+h, x:x+w] #slice the face from the image1
        face = cv2.resize(face,(0,0),None,0.25,0.25)
        EncodeCam = face_recognition.face_encodings(face)
        for i in range(0,len(encodeList)-1):
                result = face_recognition.compare_faces(EncodeCam, encodeList[i])
                try:
                    if result[0] == True:
                        cv2.putText(frame, 
                                (names[i].upper()), 
                                ((x+(w)), (y+h)), 
                                font, 1, 
                                (0, 255, 255), 
                                2, 
                                cv2.LINE_4)
                except:
                    pass
        cv2.rectangle(frame , (x , y) , (x+w , y+h) , (255 ,0  , 0) , 5)
        


    cv2.imshow("show", frame)
    key = cv2.waitKey(1)

    if key==81 or key ==113:
        break



