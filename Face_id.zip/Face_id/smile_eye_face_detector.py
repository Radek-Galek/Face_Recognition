import cv2
import dlib

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades +'haarcascade_frontalface_default.xml')
eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades +'haarcascade_eye.xml')
smile_cascade = cv2.CascadeClassifier(cv2.data.haarcascades +'haarcascade_smile.xml')



webcam = cv2.VideoCapture(0)
#img = cv2.imread("/Users/radekgalek/Documents/code/obi-wan.png")
while True:
    successful_frame_read, frame = webcam.read()
    grayscaled_img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY,1)
    face_coordinates = face_cascade.detectMultiScale(grayscaled_img, 1.3, 5)

    for (x, y, w, h) in face_coordinates:
        roi_gray = grayscaled_img[y:y + h, x:x + w]
        roi_color = frame[y:y + h, x:x + w]
        smiles = smile_cascade.detectMultiScale(roi_gray, 1.8, 15)
        eyes = eye_cascade.detectMultiScale(roi_gray, 1.8, 15)

    for (x , y , w , h) in face_coordinates:
        cv2.rectangle(frame , (x , y) , (x+w , y+h) , (255 ,0  , 0) , 5)
        for (x2 , y2 , w2 , h2) in smiles:
            cv2.rectangle(roi_color, (x2, y2), ((x2 + w2), (y2 + h2)), (0, 0, 255), 5)
        for (x3 , y3 , w3 , h3) in eyes:
            cv2.rectangle(roi_color, (x3, y3), ((x3 + w3), (y3 + h3)), (0, 255, 0), 5)


    cv2.imshow("show", frame)
    key = cv2.waitKey(1)

    if key==81 or key ==113:
        break

print("code completed")
