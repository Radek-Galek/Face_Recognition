'''
Face recognition program to detect whether a face is one of the images saved in the images folder.
'''

#import all of the necessary modules
import cv2
import face_recognition
import os
import numpy as np

#save the path to the folder containing the images
path = '/Users/radekgalek/Documents/code/Face_id_program/Images'

#XML file containing the algorithm to detect faces
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades +'haarcascade_frontalface_default.xml')

#all of the lists to store data
images = []
names = []
encodeList = []


for img in os.listdir(path):
    # removes all files starting with a dot
    if not img.startswith('.'):
        #loads all of the images from the path directory and turns them into rgb and add to list with images and names of the files
        pic = face_recognition.load_image_file(os.path.join(path,img))
        pic = cv2.cvtColor(pic,cv2.COLOR_BGR2RGB)
        images.append(pic)
        names.append(img.rsplit( ".", 1 )[ 0 ] )

#start capturing the camera
webcam = cv2.VideoCapture(0)

    
#encodes all of the images and adds them to a list with encoded images so that the can be compared with all the faces in the videoCapture
for img in images:
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    encode = face_recognition.face_encodings(img)[0]
    encodeList.append(encode)


while True:
    #reads the webcam video
    successful_frame_read, frame = webcam.read()

    #turns the image into grayscale and saves the coordinates of the face
    grayscaled_img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY,1)
    face_coordinates = face_cascade.detectMultiScale(grayscaled_img, 1.3, 5)

    #highlights the face with a rectangle and checks wether each face in the frame matches with an image 
    for (x , y , w , h) in face_coordinates:

        #draws a rectangle around the face
        cv2.rectangle(frame , (x , y) , (x+w , y+h) , (255 ,0  , 0) , 5)

        #slice the face from the frame
        face = frame[y:y+h, x:x+w] 

        ##resizes the face image and encodes it 
        face = cv2.resize(face,(0,0),None,0.25,0.25)
        EncodeCam = face_recognition.face_encodings(face)

        #loop to check wether the face matches with any image
        for i in range(0,len(encodeList)):

                result = face_recognition.compare_faces(EncodeCam, encodeList[i], tolerance=0.5)
                #displays text next to the face if the face matches
                try:
                    if result[0] == True:
                        cv2.putText(frame, 
                                (names[i].upper()), 
                                ((x+(w)), (y+h)), 
                                cv2.FONT_HERSHEY_COMPLEX, 1, 
                                (0, 255, 255), 
                                2, 
                                cv2.LINE_4)
                except:
                    pass
        

    #shows the face on the screen
    cv2.imshow("Face Recognition", frame)
    key = cv2.waitKey(1)

    #gives you the ability to exit the app
    if key==81 or key ==113:
        break



